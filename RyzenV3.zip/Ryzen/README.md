# 🤖Naga-Bot🤖
BOT WHATSAPP TERMUX ONLY BY Sekaii Mod

### Alat dan Bahan
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan kode qr kak)
> jaringan internet kenceng,kuota+
> penyimpanan yang memadai
> aplikasi whatsapp
> jika error hubungi 088235435804
> aplikasi termux
> kopi nya diminum..
```

### Cara Installnya

```bash
> kalo lu belum punya apk termux, download di playstore !
> masuk ke apk termux lalu ketik dibawah ini!
> termux-setup-storage
> pkg install git && pkg install wget && pkg install ffmpeg && pkg install nodejs
> apt update && apt upgrade
> cd Arya-Bot
> npm i -g cwebp && npm i -g ytdl && npm i  && npm i got && node index js
> Tinggal scan kode qr ya cuy...done cuk
```

## Features

| Nolep Bot     |                   Feature        |
| :-----------: | :------------------------------: |
|       ✅       | Sticker Creator                  |
|       ✅       | Nulis                           |
|       ✅       | Covid (new)                      |
|       ✅       | Alay (new)                       |
|       ✅       | Lirik (new)                      |
|       ✅       | Foto Anime                       |
|       ✅       | Foto cewek/cowok (new)           |
|       ✅       | Pantun                           |
|       ✅       | Youtube Downloader               |
|       ✅       | Quotes                           |
|       ✅       | Nama (new)                       |
|       ✅       | Foto Anime                       |
|       ✅       | Pasangan (new)                   |
|       ✅       | Sholat (new )                    |
|       ✅       | Suara Google (fix)               |
|       ✅       | Quran                            |
|       ✅       | Youtube MP3 Downloader           |
|       ✅       | Intagram Downloader              |
|       ✅       | Twitter Downloader               |
|       ✅       | Facebook Downloader              |
|       ✅       | TikTok Downloader  (new)         |
|       ✅       | Wikipedia                        |
|       ✅       | Say                              |
|       ✅       | Toxic (new)                      |
|       ✅       | loli                             |
|       ✅       | hentai                           |
|       ✅       | Owner (new)                      |
|       ✅       | kata bijak                       |
|       ✅       | Fakta                            |
|       ✅       | Pokemon                          |
|       ✅       | Info                             |
|       ✅       | Donate                           |
|                   MORE                           |

Ket: Aktiv 24 jam
Jika ada kendala hubungi kami..

## Note
BOT INI KHUSUS HP/TERMUX DOANG YAH,JIKA MAU RE-UPLOAD CANTUMKAN NAMA SAYA (NFQ SQUAD)

## Sosial Media Admin
* [`Youtube Admin`](https://youtube.com/channel/UC7di1zjUfd3h4A58a2uscIw) 
* [`WhatsApp Admin `](https://wa.me/6283807588767)
